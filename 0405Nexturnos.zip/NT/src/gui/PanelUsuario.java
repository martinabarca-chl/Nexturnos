package gui;
import javax.swing.JOptionPane;

public class PanelUsuario {
    private String email;
    public PanelUsuario(String email) { this.email = email; }
    public void mostrar() {
        JOptionPane.showMessageDialog(null, "Bienvenido Usuario: " + email);
    }
}