package gui;
import javax.swing.JOptionPane;

public class PanelNegocio {
    private String email;
    public PanelNegocio(String email) { this.email = email; }
    public void mostrar() {
        JOptionPane.showMessageDialog(null, "Bienvenido Negocio: " + email);
    }
}