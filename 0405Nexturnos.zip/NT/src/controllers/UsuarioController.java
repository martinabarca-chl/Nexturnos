package controllers;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UsuarioController {

    // =====================================================
    // AUTENTICAR USUARIO
    // Retorna el tipo si las credenciales son correctas
    // Retorna null si son incorrectas o hay error
    // =====================================================
    public static String autenticar(String email, String password) {

        String sql = "SELECT tipo FROM usuarios " +
                     "WHERE email = ? AND password = ? AND activo = true";

        Conexion db = new Conexion();
        Connection con = db.getConnection();

        if (con == null) return null;

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String tipo = rs.getString("tipo");
                rs.close();
                ps.close();
                db.close();
                return tipo; // "admin", "usuario" o "negocio"
            }

            rs.close();
            ps.close();

        } catch (SQLException e) {
            System.out.println("❌ Error al autenticar usuario");
            e.printStackTrace();
        } finally {
            db.close();
        }

        return null; // credenciales incorrectas
    }

    // =====================================================
    // REGISTRAR USUARIO
    // Retorna true si se registró correctamente
    // =====================================================
    public static boolean registrar(String nombre, String email, String password) {

        String sql = "INSERT INTO usuarios (nombre, email, password, tipo) " +
                     "VALUES (?, ?, ?, 'usuario')";

        Conexion db = new Conexion();
        Connection con = db.getConnection();

        if (con == null) return false;

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, email);
            ps.setString(3, password);

            ps.executeUpdate();
            ps.close();
            return true;

        } catch (SQLException e) {
            // El email ya existe (UNIQUE en la tabla)
            if (e.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(null,
                    "El correo ingresado ya está registrado.",
                    "Email duplicado",
                    JOptionPane.WARNING_MESSAGE);
            } else {
                System.out.println("❌ Error al registrar usuario");
                e.printStackTrace();
            }
        } finally {
            db.close();
        }

        return false;
    }

    // =====================================================
    // OBTENER ID POR EMAIL
    // Útil para los demás controllers
    // =====================================================
    public static int obtenerIdPorEmail(String email) {

        String sql = "SELECT id_usuario FROM usuarios WHERE email = ?";

        Conexion db = new Conexion();
        Connection con = db.getConnection();

        if (con == null) return -1;

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id_usuario");
                rs.close();
                ps.close();
                return id;
            }

            rs.close();
            ps.close();

        } catch (SQLException e) {
            System.out.println("❌ Error al obtener ID de usuario");
            e.printStackTrace();
        } finally {
            db.close();
        }

        return -1; // no encontrado
    }
}