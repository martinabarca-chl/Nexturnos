package gui;

import controllers.UsuarioController;
import javax.swing.*;
import java.awt.*;

public class CrearCuentaFrame {

    public void mostrar() {

        JPanel panel = new JPanel(new BorderLayout(0, 15));

        JLabel titulo = new JLabel("Crear Cuenta");
        titulo.setFont(new Font("Arial Black", Font.BOLD, 20));
        titulo.setForeground(new Color(0, 102, 204));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titulo, BorderLayout.NORTH);

        JPanel campos = new JPanel(new GridLayout(3, 2, 5, 8));
        JTextField nombreField = new JTextField();
        JTextField emailField  = new JTextField();
        JPasswordField passField = new JPasswordField();

        campos.add(new JLabel("Nombre completo:"));
        campos.add(nombreField);
        campos.add(new JLabel("Correo electrónico:"));
        campos.add(emailField);
        campos.add(new JLabel("Contraseña:"));
        campos.add(passField);

        panel.add(campos, BorderLayout.CENTER);

        int opcion = JOptionPane.showOptionDialog(
            null,
            panel,
            "Crear Cuenta — NexTurnos",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            new String[]{"Registrarse", "Cancelar"},
            "Registrarse"
        );

        if (opcion == 0) {

            String nombre   = nombreField.getText().trim();
            String email    = emailField.getText().trim();
            String password = new String(passField.getPassword()).trim();

            if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null,
                    "Todos los campos son obligatorios.",
                    "Campos vacíos",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean exito = UsuarioController.registrar(nombre, email, password);

            if (exito) {
                JOptionPane.showMessageDialog(null,
                    "Cuenta creada exitosamente.\nYa puedes iniciar sesión.",
                    "Registro exitoso",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}