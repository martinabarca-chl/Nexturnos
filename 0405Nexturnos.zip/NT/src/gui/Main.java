package gui;

import conexion.Conexion;
import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Iniciando NexTurnos ===");
        new LoginFrame().mostrar();
    }
}