from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import session

import pymysql
from datetime import date
from datetime import datetime
from datetime import timedelta

app = Flask(__name__)

app.secret_key = "proyectos"

# CONEXIÓN MYSQL
conexion = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="proyectos"
)


def asegurar_columna_precio():
    cursor = conexion.cursor()

    cursor.execute("SHOW COLUMNS FROM servicios LIKE 'precio'")

    columna = cursor.fetchone()

    if columna is None:
        cursor.execute(
            "ALTER TABLE servicios ADD COLUMN precio DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER duracion"
        )
        conexion.commit()


def asegurar_columna_descripcion_publica():
    cursor = conexion.cursor()

    cursor.execute("SHOW COLUMNS FROM usuarios LIKE 'descripcion_publica'")

    columna = cursor.fetchone()

    if columna is None:
        cursor.execute(
            "ALTER TABLE usuarios ADD COLUMN descripcion_publica TEXT NULL AFTER slug"
        )
        conexion.commit()


def asegurar_columnas_cliente_reserva():
    cursor = conexion.cursor()

    columnas = {
        "cliente_nombre": "ALTER TABLE reservas ADD COLUMN cliente_nombre VARCHAR(100) NULL AFTER estado",
        "cliente_apellido": "ALTER TABLE reservas ADD COLUMN cliente_apellido VARCHAR(100) NULL AFTER cliente_nombre",
        "cliente_numero": "ALTER TABLE reservas ADD COLUMN cliente_numero VARCHAR(30) NULL AFTER cliente_apellido",
        "cliente_email": "ALTER TABLE reservas ADD COLUMN cliente_email VARCHAR(150) NULL AFTER cliente_numero"
    }

    for columna, sql in columnas.items():
        cursor.execute("SHOW COLUMNS FROM reservas LIKE %s", (columna,))

        if cursor.fetchone() is None:
            cursor.execute(sql)

    cursor.execute("SHOW COLUMNS FROM reservas LIKE 'id_usuario'")

    id_usuario = cursor.fetchone()

    if id_usuario and id_usuario[2] == "NO":
        cursor.execute("ALTER TABLE reservas MODIFY id_usuario INT NULL")

    conexion.commit()


def generar_bloques_horarios(hora_inicio, hora_fin):
    inicio = datetime.strptime(hora_inicio, "%H:%M")
    fin = datetime.strptime(hora_fin, "%H:%M")
    bloques = []

    while inicio < fin:
        bloques.append(inicio.strftime("%H:%M"))
        inicio = inicio + timedelta(minutes=30)

    return bloques


def validar_servicios_negocio(cursor, ids_servicios, id_negocio):
    if len(ids_servicios) == 0:
        return False

    placeholders = ", ".join(["%s"] * len(ids_servicios))

    sql = f"""
    SELECT COUNT(*)
    FROM servicios
    WHERE id_negocio=%s
    AND id_servicio IN ({placeholders})
    """

    cursor.execute(sql, [id_negocio] + ids_servicios)

    total = cursor.fetchone()[0]

    return total == len(ids_servicios)


def asignar_servicios_personal(cursor, id_personal, ids_servicios):
    cursor.execute(
        "DELETE FROM personal_servicio WHERE id_personal=%s",
        (id_personal,)
    )

    sql = """
    INSERT INTO personal_servicio
    (id_personal, id_servicio)

    VALUES (%s, %s)
    """

    for id_servicio in ids_servicios:
        cursor.execute(sql, (id_personal, id_servicio))


# LOGIN
@app.route("/", methods=["GET", "POST"])
def login():

    mensaje = request.args.get("mensaje", "")
    next_url = request.args.get("next", "")

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]
        next_url = request.form.get("next", "")

        cursor = conexion.cursor()

        sql = """
        SELECT *
        FROM usuarios
        WHERE email=%s AND password=%s
        """

        cursor.execute(sql, (email, password))

        usuario = cursor.fetchone()

        if usuario:

            session["id_usuario"] = usuario[0]
            session["usuario"] = usuario[1]
            session["email"] = usuario[2]
            session["tipo"] = usuario[4]

            if next_url != "":
                return redirect(next_url)

            return redirect("/dashboard")

        else:
            mensaje = "Correo o contraseña incorrectos"

    return render_template(
        "login.html",
        mensaje=mensaje,
        next_url=next_url
    )


# REGISTRO
@app.route("/register", methods=["GET", "POST"])
def register():

    mensaje = ""
    next_url = request.args.get("next", "")

    if request.method == "POST":

        nombre = request.form["nombre"]
        email = request.form["email"]
        password = request.form["password"]
        tipo = request.form["tipo"]
        slug = request.form.get("slug")
        next_url = request.form.get("next", "")

        if tipo == "usuario":
            slug = None

        if tipo == "negocio" and (slug is None or slug == ""):
            mensaje = "El negocio debe ingresar un nombre para su link público"

            return render_template(
                "register.html",
                mensaje=mensaje,
                next_url=next_url
            )

        cursor = conexion.cursor()

        sql = """
        INSERT INTO usuarios
        (nombre, email, password, tipo, slug)

        VALUES (%s, %s, %s, %s, %s)
        """

        try:
            cursor.execute(
                sql,
                (nombre, email, password, tipo, slug)
            )

            conexion.commit()

            if next_url != "":
                return redirect(
                    "/?mensaje=Cuenta creada correctamente. Ahora inicia sesión&next=" + next_url
                )

            mensaje = "Usuario registrado correctamente"

        except pymysql.err.IntegrityError:
            mensaje = "Ese correo o link público ya está registrado"

    return render_template(
        "register.html",
        mensaje=mensaje,
        next_url=next_url
    )


# DASHBOARD GENERAL SEGÚN ROL
@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():

    if "usuario" not in session:
        return redirect("/")

    tipo = session["tipo"]

    if tipo == "admin":
        return render_template(
            "dashboard_admin.html",
            usuario=session["usuario"]
        )

    elif tipo == "negocio":
        asegurar_columna_descripcion_publica()

        mensaje = ""
        id_negocio = session["id_usuario"]

        cursor = conexion.cursor()

        if request.method == "POST":
            descripcion_publica = request.form["descripcion_publica"]

            sql_update = """
            UPDATE usuarios
            SET descripcion_publica=%s
            WHERE id_usuario=%s AND tipo='negocio'
            """

            cursor.execute(sql_update, (descripcion_publica, id_negocio))

            conexion.commit()

            mensaje = "Descripcion publica actualizada correctamente"

        sql_negocio = """
        SELECT descripcion_publica
        FROM usuarios
        WHERE id_usuario=%s AND tipo='negocio'
        """

        cursor.execute(sql_negocio, (id_negocio,))

        negocio = cursor.fetchone()

        descripcion_publica = ""

        if negocio and negocio[0]:
            descripcion_publica = negocio[0]

        return render_template(
            "dashboard_negocio.html",
            usuario=session["usuario"],
            descripcion_publica=descripcion_publica,
            mensaje=mensaje
        )

    elif tipo == "usuario":
        return render_template(
            "dashboard_usuario.html",
            usuario=session["usuario"]
        )

    else:
        return redirect("/")


# SERVICIOS DEL NEGOCIO
@app.route("/servicios", methods=["GET", "POST"])
def servicios():

    if "usuario" not in session:
        return redirect("/")

    if session["tipo"] != "negocio":
        return redirect("/dashboard")

    mensaje = ""

    id_negocio = session["id_usuario"]

    asegurar_columna_precio()

    cursor = conexion.cursor()

    if request.method == "POST":

        accion = request.form.get("accion", "crear")

        if accion == "crear":

            nombre = request.form["nombre"]
            duracion = request.form["duracion"]
            precio = request.form["precio"]

            sql_insert = """
            INSERT INTO servicios
            (id_negocio, nombre, duracion, precio)

            VALUES (%s, %s, %s, %s)
            """

            cursor.execute(
                sql_insert,
                (id_negocio, nombre, duracion, precio)
            )

            conexion.commit()

            mensaje = "Servicio creado correctamente"

        elif accion == "editar":

            id_servicio = request.form["id_servicio"]
            nombre = request.form["nombre"]
            duracion = request.form["duracion"]
            precio = request.form["precio"]

            sql_update = """
            UPDATE servicios
            SET nombre=%s, duracion=%s, precio=%s
            WHERE id_servicio=%s AND id_negocio=%s
            """

            cursor.execute(
                sql_update,
                (nombre, duracion, precio, id_servicio, id_negocio)
            )

            conexion.commit()

            if cursor.rowcount > 0:
                mensaje = "Servicio actualizado correctamente"
            else:
                mensaje = "Servicio no encontrado"

        elif accion == "borrar":

            id_servicio = request.form["id_servicio"]

            sql_servicio = """
            SELECT id_servicio
            FROM servicios
            WHERE id_servicio=%s AND id_negocio=%s
            """

            cursor.execute(sql_servicio, (id_servicio, id_negocio))

            servicio = cursor.fetchone()

            if servicio is None:
                mensaje = "Servicio no encontrado"

            else:
                sql_reservas = """
                SELECT COUNT(*)
                FROM reservas
                WHERE id_servicio=%s
                """

                cursor.execute(sql_reservas, (id_servicio,))

                total_reservas = cursor.fetchone()[0]

                if total_reservas > 0:
                    mensaje = "No se puede borrar un servicio con reservas registradas"

                else:
                    cursor.execute(
                        "DELETE FROM personal_servicio WHERE id_servicio=%s",
                        (id_servicio,)
                    )

                    cursor.execute(
                        "DELETE FROM servicios WHERE id_servicio=%s AND id_negocio=%s",
                        (id_servicio, id_negocio)
                    )

                    conexion.commit()

                    mensaje = "Servicio borrado correctamente"

    sql_select = """
    SELECT id_servicio, nombre, duracion, precio
    FROM servicios
    WHERE id_negocio=%s
    """

    cursor.execute(sql_select, (id_negocio,))

    servicios = cursor.fetchall()

    return render_template(
        "servicios.html",
        servicios=servicios,
        mensaje=mensaje
    )


# PERSONAL DEL NEGOCIO
@app.route("/personal", methods=["GET", "POST"])
def personal():

    if "usuario" not in session:
        return redirect("/")

    if session["tipo"] != "negocio":
        return redirect("/dashboard")

    mensaje = ""

    id_negocio = session["id_usuario"]

    asegurar_columna_precio()

    cursor = conexion.cursor()

    if request.method == "POST":

        accion = request.form["accion"]

        if accion == "crear":

            nombre = request.form["nombre"]
            cargo = request.form["cargo"]
            ids_servicios = request.form.getlist("ids_servicios")
            hora_inicio = request.form["hora_inicio"]
            hora_fin = request.form["hora_fin"]

            if not validar_servicios_negocio(cursor, ids_servicios, id_negocio):
                mensaje = "Selecciona servicios validos"

            else:
                sql_insert = """
                INSERT INTO personal
                (id_negocio, nombre, cargo, hora_inicio, hora_fin)

                VALUES (%s, %s, %s, %s, %s)
                """

                cursor.execute(
                    sql_insert,
                    (id_negocio, nombre, cargo, hora_inicio, hora_fin)
                )

                id_personal = cursor.lastrowid

                asignar_servicios_personal(cursor, id_personal, ids_servicios)

                conexion.commit()

                mensaje = "Personal agregado y vinculado a los servicios correctamente"

        elif accion == "editar":

            id_personal = request.form["id_personal"]
            ids_servicios = request.form.getlist("ids_servicios")
            hora_inicio = request.form["hora_inicio"]
            hora_fin = request.form["hora_fin"]

            sql_personal = """
            SELECT id_personal
            FROM personal
            WHERE id_personal=%s AND id_negocio=%s
            """

            cursor.execute(sql_personal, (id_personal, id_negocio))

            persona = cursor.fetchone()

            if persona is None:
                mensaje = "Personal no encontrado"

            elif not validar_servicios_negocio(cursor, ids_servicios, id_negocio):
                mensaje = "Selecciona servicios validos"

            else:
                sql_update = """
                UPDATE personal
                SET hora_inicio=%s, hora_fin=%s
                WHERE id_personal=%s AND id_negocio=%s
                """

                cursor.execute(
                    sql_update,
                    (hora_inicio, hora_fin, id_personal, id_negocio)
                )

                asignar_servicios_personal(cursor, id_personal, ids_servicios)

                conexion.commit()

                mensaje = "Personal actualizado correctamente"

        elif accion == "borrar":

            id_personal = request.form["id_personal"]

            sql_personal = """
            SELECT id_personal
            FROM personal
            WHERE id_personal=%s AND id_negocio=%s
            """

            cursor.execute(sql_personal, (id_personal, id_negocio))

            persona = cursor.fetchone()

            if persona is None:
                mensaje = "Personal no encontrado"

            else:
                try:
                    cursor.execute(
                        "DELETE FROM personal_servicio WHERE id_personal=%s",
                        (id_personal,)
                    )

                    cursor.execute(
                        "DELETE FROM personal WHERE id_personal=%s AND id_negocio=%s",
                        (id_personal, id_negocio)
                    )

                    conexion.commit()

                    mensaje = "Personal borrado correctamente"

                except pymysql.err.IntegrityError:
                    conexion.rollback()

                    sql_desactivar = """
                    UPDATE personal
                    SET activo=0
                    WHERE id_personal=%s AND id_negocio=%s
                    """

                    cursor.execute(sql_desactivar, (id_personal, id_negocio))

                    conexion.commit()

                    mensaje = "Personal desactivado porque tiene reservas registradas"

    sql_servicios = """
    SELECT id_servicio, nombre
    FROM servicios
    WHERE id_negocio=%s
    """

    cursor.execute(sql_servicios, (id_negocio,))

    servicios = cursor.fetchall()

    sql_select = """
    SELECT
        p.id_personal,
        p.nombre,
        p.cargo,
        TIME_FORMAT(p.hora_inicio, '%%H:%%i'),
        TIME_FORMAT(p.hora_fin, '%%H:%%i'),
        p.activo,
        COALESCE(GROUP_CONCAT(s.nombre SEPARATOR ', '), 'Sin servicio'),
        COALESCE(GROUP_CONCAT(s.id_servicio SEPARATOR ','), '')
    FROM personal p
    LEFT JOIN personal_servicio ps
        ON p.id_personal = ps.id_personal
    LEFT JOIN servicios s
        ON ps.id_servicio = s.id_servicio
    WHERE p.id_negocio=%s AND p.activo=1
    GROUP BY
        p.id_personal,
        p.nombre,
        p.cargo,
        p.hora_inicio,
        p.hora_fin,
        p.activo
    """

    cursor.execute(sql_select, (id_negocio,))

    personal = cursor.fetchall()

    personal_con_servicios = []

    for persona in personal:
        ids_servicios = []

        if persona[7] != "":
            ids_servicios = persona[7].split(",")

        personal_con_servicios.append({
            "id": persona[0],
            "nombre": persona[1],
            "cargo": persona[2],
            "hora_inicio": persona[3],
            "hora_fin": persona[4],
            "activo": persona[5],
            "servicios": persona[6],
            "ids_servicios": ids_servicios
        })

    return render_template(
        "personal.html",
        personal=personal_con_servicios,
        servicios=servicios,
        mensaje=mensaje
    )


# RESERVAS DEL NEGOCIO
@app.route("/reservas-negocio")
def reservas_negocio():

    if "usuario" not in session:
        return redirect("/")

    if session["tipo"] != "negocio":
        return redirect("/dashboard")

    id_negocio = session["id_usuario"]

    asegurar_columnas_cliente_reserva()

    cursor = conexion.cursor()

    sql = """
    SELECT
        r.id_reserva,
        COALESCE(
            NULLIF(CONCAT_WS(' ', r.cliente_nombre, r.cliente_apellido), ''),
            u.nombre,
            'Cliente'
        ),
        s.nombre,
        p.nombre,
        r.fecha,
        TIME_FORMAT(r.hora, '%%H:%%i'),
        r.estado,
        r.cliente_nombre,
        r.cliente_apellido,
        r.cliente_numero,
        r.cliente_email
    FROM reservas r
    LEFT JOIN usuarios u
        ON r.id_usuario = u.id_usuario
    INNER JOIN servicios s
        ON r.id_servicio = s.id_servicio
    INNER JOIN personal p
        ON r.id_personal = p.id_personal
    WHERE s.id_negocio=%s
    ORDER BY r.fecha, r.hora
    """

    cursor.execute(sql, (id_negocio,))

    reservas = cursor.fetchall()

    return render_template(
        "reservas_negocio.html",
        reservas=reservas
    )


# PÁGINA PÚBLICA DEL NEGOCIO
@app.route("/negocios/<slug>")
def negocio_publico(slug):

    asegurar_columna_precio()
    asegurar_columna_descripcion_publica()

    mensaje = request.args.get("mensaje", "")

    cursor = conexion.cursor()

    sql_negocio = """
    SELECT id_usuario, nombre, slug, descripcion_publica
    FROM usuarios
    WHERE slug=%s AND tipo='negocio'
    """

    cursor.execute(sql_negocio, (slug,))

    negocio = cursor.fetchone()

    if not negocio:
        return "Negocio no encontrado"

    id_negocio = negocio[0]

    sql_servicios = """
    SELECT id_servicio, nombre, duracion, precio
    FROM servicios
    WHERE id_negocio=%s
    """

    cursor.execute(sql_servicios, (id_negocio,))

    servicios = cursor.fetchall()

    servicios_con_personal = []

    for servicio in servicios:

        id_servicio = servicio[0]

        sql_personal = """
        SELECT 
            p.id_personal,
            p.nombre,
            p.cargo,
            TIME_FORMAT(p.hora_inicio, '%%H:%%i'),
            TIME_FORMAT(p.hora_fin, '%%H:%%i')
        FROM personal_servicio ps
        INNER JOIN personal p
            ON ps.id_personal = p.id_personal
        WHERE ps.id_servicio=%s
        AND p.activo=1
        """

        cursor.execute(sql_personal, (id_servicio,))

        personal_servicio = cursor.fetchall()

        servicios_con_personal.append({
            "servicio": servicio,
            "personal": personal_servicio
        })

    return render_template(
        "negocio_publico.html",
        negocio=negocio,
        servicios_con_personal=servicios_con_personal,
        mensaje=mensaje
    )


# RESERVAR CON SERVICIO Y PERSONAL
@app.route("/reservar/<int:id_servicio>/<int:id_personal>", methods=["GET", "POST"])
def reservar(id_servicio, id_personal):

    asegurar_columna_precio()
    asegurar_columnas_cliente_reserva()

    cursor = conexion.cursor()

    sql_info = """
    SELECT
        s.id_servicio,
        s.nombre,
        s.duracion,
        s.precio,
        p.id_personal,
        p.nombre,
        TIME_FORMAT(p.hora_inicio, '%%H:%%i'),
        TIME_FORMAT(p.hora_fin, '%%H:%%i'),
        u.nombre,
        u.slug
    FROM servicios s
    INNER JOIN personal_servicio ps
        ON s.id_servicio = ps.id_servicio
    INNER JOIN personal p
        ON ps.id_personal = p.id_personal
    INNER JOIN usuarios u
        ON s.id_negocio = u.id_usuario
    WHERE s.id_servicio=%s
    AND p.id_personal=%s
    """

    cursor.execute(sql_info, (id_servicio, id_personal))

    info = cursor.fetchone()

    if not info:
        return "Servicio o personal no encontrado"

    mensaje = ""

    if request.method == "POST":

        cliente_nombre = request.form["cliente_nombre"]
        cliente_apellido = request.form["cliente_apellido"]
        cliente_numero = request.form["cliente_numero"]
        cliente_email = request.form["cliente_email"]
        fecha = request.form["fecha"]
        hora = request.form["hora"]

        id_usuario = None

        if session.get("tipo") == "usuario":
            id_usuario = session.get("id_usuario")

        sql_insert = """
        INSERT INTO reservas
        (
            id_usuario,
            id_servicio,
            id_personal,
            fecha,
            hora,
            estado,
            cliente_nombre,
            cliente_apellido,
            cliente_numero,
            cliente_email
        )

        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        cursor.execute(
            sql_insert,
            (
                id_usuario,
                id_servicio,
                id_personal,
                fecha,
                hora,
                "pendiente",
                cliente_nombre,
                cliente_apellido,
                cliente_numero,
                cliente_email
            )
        )

        conexion.commit()

        return redirect(
            "/negocios/"
            + info[9]
            + "?mensaje=Reserva%20confirmada%20correctamente"
        )

    if False:

        fecha = request.form["fecha"]
        hora = request.form["hora"]

        id_usuario = session["id_usuario"]

        # VALIDAR SI YA EXISTE UNA RESERVA EN ESA FECHA, HORA Y PERSONAL
        sql_validar = """
        SELECT id_reserva
        FROM reservas
        WHERE id_personal=%s
        AND fecha=%s
        AND hora=%s
        AND estado!='cancelada'
        """

        cursor.execute(sql_validar, (id_personal, fecha, hora))

        reserva_existente = cursor.fetchone()

        if reserva_existente:
            mensaje = "Ese horario ya está ocupado. Elige otra hora."

        else:
            sql_insert = """
            INSERT INTO reservas
            (id_usuario, id_servicio, id_personal, fecha, hora, estado)

            VALUES (%s, %s, %s, %s, %s, %s)
            """

            cursor.execute(
                sql_insert,
                (
                    id_usuario,
                    id_servicio,
                    id_personal,
                    fecha,
                    hora,
                    "pendiente"
                )
            )

            conexion.commit()

            return redirect(
                "/negocios/"
                + info[9]
                + "?mensaje=Reserva%20confirmada%20correctamente"
            )

    fecha_actual = date.today().isoformat()
    bloques_horarios = generar_bloques_horarios(info[6], info[7])

    return render_template(
        "reservar.html",
        info=info,
        mensaje=mensaje,
        fecha_actual=fecha_actual,
        bloques_horarios=bloques_horarios
    )


# LOGOUT
@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")


# EJECUTAR APP
if __name__ == "__main__":
    app.run(debug=True)
