package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    private static final String DRIVER   = "com.mysql.cj.jdbc.Driver";
    private static final String URL      = "jdbc:mysql://localhost:3306/proyectos"
                                         + "?useSSL=false"
                                         + "&allowPublicKeyRetrieval=true"
                                         + "&serverTimezone=UTC";
    private static final String USUARIO  = "root";
    private static final String PASSWORD = "";

    private Connection con;

    // Carga el driver una sola vez al iniciar
    static {
        try {
            Class.forName(DRIVER);
            System.out.println("✅ Driver MySQL cargado correctamente");
        } catch (ClassNotFoundException e) {
            System.out.println("❌ Driver MySQL no encontrado");
            e.printStackTrace();
        }
    }

    // Abre la conexión
    public Connection getConnection() {
        try {
            con = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            System.out.println("✅ Conexión exitosa a la base de datos nexturnos");
            return con;
        } catch (SQLException e) {
            System.out.println("❌ Error al conectar con la base de datos");
            JOptionPane.showMessageDialog(null,
                "No se pudo conectar a la base de datos.\n" +
                "Verifica que MySQL esté activo en XAMPP.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    // Cierra la conexión
    public void close() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("🔒 Conexión cerrada correctamente");
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al cerrar la conexión");
            e.printStackTrace();
        }
    }
}