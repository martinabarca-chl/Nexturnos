package gui;

import controllers.UsuarioController;
import javax.swing.*;
import java.awt.*;

public class LoginFrame {

    public void mostrar() {

        while (true) {

            // Panel principal
            JPanel panel = new JPanel(new BorderLayout(0, 15));

            // Logo
            JLabel logo = new JLabel("NexTurnos");
            logo.setFont(new Font("Arial Black", Font.BOLD, 28));
            logo.setForeground(new Color(0, 102, 204));
            logo.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(logo, BorderLayout.NORTH);

            // Campos
            JPanel campos = new JPanel(new GridLayout(2, 2, 5, 8));
            JTextField emailField    = new JTextField();
            JPasswordField passField = new JPasswordField();

            campos.add(new JLabel("Correo electrónico:"));
            campos.add(emailField);
            campos.add(new JLabel("Contraseña:"));
            campos.add(passField);

            panel.add(campos, BorderLayout.CENTER);

            // Botones
            int opcion = JOptionPane.showOptionDialog(
                null,
                panel,
                "Iniciar Sesión — NexTurnos",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                new String[]{"Iniciar Sesión", "Crear Cuenta", "Salir"},
                "Iniciar Sesión"
            );

            // Salir o cerrar ventana
            if (opcion == 2 || opcion == JOptionPane.CLOSED_OPTION) {
                System.out.println("👋 Sistema cerrado por el usuario");
                System.exit(0);
            }

            // Crear cuenta
            if (opcion == 1) {
                new CrearCuentaFrame().mostrar();
                continue;
            }

            // Iniciar sesión
            if (opcion == 0) {

                String email    = emailField.getText().trim();
                String password = new String(passField.getPassword()).trim();

                if (email.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null,
                        "Debes ingresar tu correo y contraseña.",
                        "Campos vacíos",
                        JOptionPane.WARNING_MESSAGE);
                    continue;
                }

                String tipo = UsuarioController.autenticar(email, password);

                if (tipo != null) {
                    System.out.println("✅ Login exitoso — tipo: " + tipo);
                    abrirPanel(tipo, email);
                    return;
                } else {
                    JOptionPane.showMessageDialog(null,
                        "Correo o contraseña incorrectos.",
                        "Error de autenticación",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // Redirige al panel según el tipo de usuario
    private void abrirPanel(String tipo, String email) {
        switch (tipo) {
            case "admin":
                new PanelAdmin(email).mostrar();
                break;
            case "usuario":
                new PanelUsuario(email).mostrar();
                break;
            case "negocio":
                new PanelNegocio(email).mostrar();
                break;
            default:
                JOptionPane.showMessageDialog(null,
                    "Tipo de usuario no reconocido.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}