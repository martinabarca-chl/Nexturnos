package gui;
import javax.swing.JOptionPane;

public class PanelAdmin {
    private String email;
    public PanelAdmin(String email) { this.email = email; }
    public void mostrar() {
        JOptionPane.showMessageDialog(null, "Bienvenido Admin: " + email);
    }
}